from django.apps import AppConfig


class SahovskiklubConfig(AppConfig):
    name = 'SahovskiKlub'
