from .main_views import *
from .taktika_views import *
from .objavaNovosti_view import *
from .placanjeClanarine_view import *
from .profil_view import *
from .removeLista_view import *
from .trening_views import *
from .turnir_views import *
from .listaTransakcija_view import *
from .listaTaktika_view import *

